#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from flask import Flask, render_template, request
import psycopg2
from code_files.blank_generation import create_blank, create_blank_emoji
from code_files.scoring import get_points, scoring_emoji


def get_db_connection():
    DB_NAME = "team_f_db"
    DB_USER = "postgres"
    DB_PASS = "d3e8db4016b1e148da8a12e4f361be44"
    DB_HOST = "172.23.115.137"
    DB_PORT = "50840"

    # Connecting to PostgreSQL DBMS
    connection = psycopg2.connect(database=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
    return connection


app = Flask(__name__, template_folder='templates')


@app.route('/', methods=('GET',))
def home():
    if request.method == "GET":
        return render_template("home.html")
    elif request.method == "POST":
        return None


@app.route('/word_guesser_noun', methods=('GET',))
def wgame_noun():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM final
        WHERE is_sfw=true
        AND contains_noun = true
        ORDER BY RANDOM()
        LIMIT 1''')
    rdm = cursor.fetchall()
    tweet_blank, solution = create_blank('NOUN', rdm[0][1], rdm[0][7])
    user_name = rdm[0][2]
    screen_name = rdm[0][3]
    faves = rdm[0][4]
    retweets = rdm[0][5]
    date_time = rdm[0][6]
    tweet = {"blank": tweet_blank,
             "solution": solution,
             "user_name": user_name,
             "screen_name": screen_name,
             "faves": faves,
             "retweets": retweets,
             "date_time": date_time}
    mode = '/word_guesser_noun'
    active = {'noun': 'active', 'verb': '', 'adj': ''}
    if request.method == "GET":
        return render_template('word_guesser.html', tweet=tweet, mode=mode, active=active)


@app.route('/word_guesser_verb', methods=('GET',))
def wgame_verb():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM final
        WHERE is_sfw=true
        AND contains_verb = true
        ORDER BY RANDOM()
        LIMIT 1''')
    rdm = cursor.fetchall()
    tweet_blank, solution = create_blank('VERB', rdm[0][1], rdm[0][7])
    user_name = rdm[0][2]
    screen_name = rdm[0][3]
    faves = rdm[0][4]
    retweets = rdm[0][5]
    date_time = rdm[0][6]
    tweet = {"blank": tweet_blank,
             "solution": solution,
             "user_name": user_name,
             "screen_name": screen_name,
             "faves": faves,
             "retweets": retweets,
             "date_time": date_time}
    mode = '/word_guesser_verb'
    active = {'noun': '', 'verb': 'active', 'adj': ''}
    if request.method == "GET":
        return render_template('word_guesser.html', tweet=tweet, mode=mode, active=active)


@app.route('/word_guesser_adj', methods=('GET',))
def wgame_adj():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM final
        WHERE is_sfw=true
        AND contains_adj = true
        ORDER BY RANDOM()
        LIMIT 1''')
    rdm = cursor.fetchall()
    tweet_blank, solution = create_blank('ADJ', rdm[0][1], rdm[0][7])
    user_name = rdm[0][2]
    screen_name = rdm[0][3]
    faves = rdm[0][4]
    retweets = rdm[0][5]
    date_time = rdm[0][6]
    tweet = {"blank": tweet_blank,
             "solution": solution,
             "user_name": user_name,
             "screen_name": screen_name,
             "faves": faves,
             "retweets": retweets,
             "date_time": date_time}
    mode = '/word_guesser_adj'
    active = {'noun': '', 'verb': '', 'adj': 'active'}
    if request.method == "GET":
        return render_template('word_guesser.html', tweet=tweet, mode=mode, active=active)


@app.route('/emoji_guesser', methods=('GET',))
def egame():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
            SELECT * FROM final
            WHERE is_sfw=true
            ORDER BY RANDOM()
            LIMIT 1''')
    rdm = cursor.fetchall()
    # tweet_blank, solution = create_blank('NOUN', rdm[0][1], rdm[0][3])
    tweet_blank, solution, suggestions = create_blank_emoji(rdm[0][1])  # playing the emoji guesser game
    user_name = rdm[0][2]
    screen_name = rdm[0][3]
    faves = rdm[0][4]
    retweets = rdm[0][5]
    date_time = rdm[0][6]
    tweet = {"blank": tweet_blank,
             "solution": solution,
             "suggestions": suggestions,
             "user_name": user_name,
             "screen_name": screen_name,
             "faves": faves,
             "retweets": retweets,
             "date_time": date_time,
             'guess': ''
             }

    if request.method == "GET":
        return render_template('emoji_guesser.html', tweet=tweet)


@app.route('/no_filter_noun', methods=('GET',))
def no_filter_noun():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
                SELECT * FROM final
                WHERE contains_noun=true
                ORDER BY RANDOM()
                LIMIT 1''')
    rdm = cursor.fetchall()
    tweet_blank, solution = create_blank('NOUN', rdm[0][1], rdm[0][7])
    user_name = rdm[0][2]
    screen_name = rdm[0][3]
    faves = rdm[0][4]
    retweets = rdm[0][5]
    date_time = rdm[0][6]
    tweet = {"blank": tweet_blank,
             "solution": solution,
             "user_name": user_name,
             "screen_name": screen_name,
             "faves": faves,
             "retweets": retweets,
             "date_time": date_time
             }
    mode = '/no_filter_noun'
    active = {'noun': 'active', 'verb': '', 'adj': ''}
    if request.method == "GET":
        return render_template('no_filter.html', tweet=tweet, mode=mode, active=active)


@app.route('/no_filter_verb', methods=('GET',))
def no_filter_verb():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
                SELECT * FROM final
                WHERE contains_verb=true
                ORDER BY RANDOM()
                LIMIT 1''')
    rdm = cursor.fetchall()
    tweet_blank, solution = create_blank('VERB', rdm[0][1], rdm[0][7])
    user_name = rdm[0][2]
    screen_name = rdm[0][3]
    faves = rdm[0][4]
    retweets = rdm[0][5]
    date_time = rdm[0][6]
    tweet = {"blank": tweet_blank,
             "solution": solution,
             "user_name": user_name,
             "screen_name": screen_name,
             "faves": faves,
             "retweets": retweets,
             "date_time": date_time
             }
    mode = '/no_filter_verb'
    active = {'noun': '', 'verb': 'active', 'adj': ''}
    if request.method == "GET":
        return render_template('no_filter.html', tweet=tweet, mode=mode, active=active)


@app.route('/no_filter_adj', methods=('GET',))
def no_filter_adj():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
                SELECT * FROM final
                WHERE contains_adj=true
                ORDER BY RANDOM()
                LIMIT 1''')
    rdm = cursor.fetchall()
    tweet_blank, solution = create_blank('ADJ', rdm[0][1], rdm[0][7])
    user_name = rdm[0][2]
    screen_name = rdm[0][3]
    faves = rdm[0][4]
    retweets = rdm[0][5]
    date_time = rdm[0][6]
    tweet = {"blank": tweet_blank,
             "solution": solution,
             "user_name": user_name,
             "screen_name": screen_name,
             "faves": faves,
             "retweets": retweets,
             "date_time": date_time
             }
    mode = '/no_filter_adj'
    active = {'noun': '', 'verb': '', 'adj': 'active'}
    if request.method == "GET":
        return render_template('no_filter.html', tweet=tweet, mode=mode, active=active)


@app.route('/result', methods=('POST',))
def result():
    if request.method == "POST":
        guess = request.form.get('guess')
        solution = request.form.get('solution')
        score = get_points(guess, solution)
        mode = request.form.get('mode')
        return render_template("score.html", score=score, solution=solution, mode=mode)


@app.route('/result_emojis', methods=('POST',))
def eresult():
    if request.method == "POST":
        guess = request.form.get('guess')
        solution = request.form.get('solution')
        score = scoring_emoji(guess, solution)
        return render_template("score_emojis.html", score=score, solution=solution)


if __name__ == "__main__":
    app.run()
