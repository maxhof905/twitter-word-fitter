#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# generate the blanks in the Tweets
# let user choose number of tweets?

import emoji
import random
import re



def create_blank(tag, tweet, tagged_str=str):  # user can decide between 'NOUN', 'NOUN and PROPN', 'VERB', 'ADJ' (technically between any tag)
    tagged = tagged_str.split('\t')
    blank_candidates = list()
    for token in tagged:
        info = token.split()
        if info and info[1] == tag and not emoji.is_emoji(info[0]) and info[3].lower() and \
                not info[0].startswith(('@', '#')) and len(info[0]) > 2:
            blank_candidates.append(info[0])
    if blank_candidates:
        blank = random.choice(blank_candidates)
        tweet_blanked = re.sub(re.escape(blank), '_ '*len(blank), tweet, 1)
        return tweet_blanked, blank
    else:
        return f"!!!error: found no blank candidated for tag {tag}\ntweet: {tweet}\ntagged= {tagged_str}"


def create_blank_emoji(tweet):
    faces = [em for name, em in emoji.EMOJI_UNICODE_ENGLISH.items() if 'face' in name]
    suggestions = set()
    blank_candidates = list()
    for character in tweet:
        if emoji.is_emoji(character) and character:
            blank_candidates.append(character)
    if blank_candidates:
        blank = random.choice(blank_candidates)
        tweet_blanked = re.sub(re.escape(blank), '_ ' * len(blank), tweet, 1)
        suggestions.update(blank)
        suggestions.update(random.sample(faces, k=3))
        return tweet_blanked, blank, [sugg for sugg in suggestions]
        # elif len(suggestions) < 4:
        #     if len(suggestions) <= 4:
        #         suggestions.update(random.choice(faces))
        #     return tweet_blanked, blank, [sugg for sugg in suggestions]
    else:
        return f"!!!error: found no blank candidated \ntweet: {tweet}"



#
# def get_random_blanked(tag, number=1):
#     blanked = create_blank(tag)
#     randm = dict()
#     for i in range(number):
#         randomed = random.choice(list(blanked.items()))
#         randm[randomed[0]] = randomed[1]
#
#     return randm


# print(get_random_blanked('NOUN', 1))

#c = create_blank('NOUN', 'Due to inflation 420 has gone up by 69', 'Due ADP IN prep 	to ADP IN pcomp 	inflation NOUN NN pobj 	420 NUM CD nummod 	has AUX VBZ aux 	gone VERB VBN ROOT 	up ADP RP prt 	by ADP IN prep 	69 NUM CD pobj 	')
